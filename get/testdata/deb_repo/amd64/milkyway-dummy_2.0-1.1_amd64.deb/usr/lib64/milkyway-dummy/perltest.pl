#! /usr/bin/perl
#

print "Hello Milkyway!\n";


